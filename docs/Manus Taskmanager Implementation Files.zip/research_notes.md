# Research Notes: state_mismatch Error in Better-Auth Expo

## Source: GitHub Issue #5034
URL: https://github.com/better-auth/better-auth/issues/5034

## Key Findings

### Root Cause
The `state_mismatch` error with Google login on Expo/iOS is caused by issues with how the OAuth state parameter is stored and retrieved during the authentication flow. On mobile, cookies and session storage behave differently than on web, so Expo-specific handling is required.

### How Better-Auth Expo Plugin Works
The `@better-auth/expo` plugin tries to work around this by propagating session cookies via URL query parameters during OAuth redirects, especially for trusted origins like `exp://` in development. If this mechanism fails, the server can't validate the state parameter, resulting in a CSRF protection error `state_mismatch`.

### Common Causes and Fixes

1. **Redirect URI configuration**: For mobile, Google does not accept localhost or private IPs as redirect URIs. Use a tunneling service like ngrok to expose your backend with a public HTTPS URL, and register this as the redirect URI in both Google Cloud Console and your Better Auth config.

2. **Trusted origins**: Make sure your Better Auth config includes the correct trusted origins for your app scheme (e.g., `exp://`, `yourapp://`).

3. **Session/cookie propagation**: Ensure your Expo client correctly extracts the session cookie from the redirect URL and sets it for subsequent API requests. If you're not handling this in your client, the session won't persist and the state won't match.

4. **Version differences**: Some workarounds for state/cookie handling changed in newer Better Auth versions.

### Related PR
Issue was closed by PR #6278: "set default to cookie to match JSDoc"

---

## Official Better-Auth Expo Documentation
URL: https://www.better-auth.com/docs/integrations/expo

### Correct Social Sign-In Implementation

The documentation shows the **correct way** to implement social sign-in in Expo:

```typescript
// app/social-sign-in.tsx
import { Button } from "react-native";
import { authClient } from "@/lib/auth-client";

export default function SocialSignIn() {
    const handleLogin = async () => {
        await authClient.signIn.social({
            provider: "google",
            // callbackURL is optional - handled by expo plugin
        });
    };
    
    return <Button title="Sign in with Google" onPress={handleLogin} />;
}
```

### Key Points from Documentation:

1. **Use `authClient.signIn.social()` method** - NOT manual fetch calls to `/api/auth/sign-in/social`

2. **The expo client plugin handles**:
   - Social Authentication Support: enables social auth flows by handling authorization URLs and callbacks within the Expo web browser
   - Secure Cookie Management: stores cookies securely and automatically adds them to the headers of auth requests

3. **Required client configuration**:
```typescript
import { createAuthClient } from "better-auth/react";
import { expoClient } from "@better-auth/expo/client";
import * as SecureStore from "expo-secure-store";

export const authClient = createAuthClient({
    baseURL: "http://localhost:8081", // or ngrok URL
    plugins: [
        expoClient({
            scheme: "myapp",
            storagePrefix: "myapp",
            storage: SecureStore,
        })
    ]
});
```

4. **Trusted Origins must include**:
   - Your app scheme: `"taskmanager://"`
   - Development mode: `"exp://"`, `"exp://**"`, `"exp://192.168.*.*:*/**"`
   - ngrok URL if using tunnel

---

## Analysis of User's Code Issues

### Issue 1: Mobile Login Implementation (apps/mobile/app/auth/login.tsx)
**PROBLEM**: The user is NOT using the better-auth client's `signIn.social()` method. Instead, they're manually:
1. Calling `fetch()` to `/api/auth/sign-in/social` endpoint
2. Using `WebBrowser.openAuthSessionAsync()` directly
3. Manually handling the callback URL and token extraction

This bypasses the expo plugin's state management mechanism entirely!

### Issue 2: Auth Client Configuration (apps/mobile/lib/auth-client.ts)
The auth client is configured but NOT being used for social sign-in. The login.tsx file doesn't even import or use `authClient`.

### Issue 3: Server Configuration (packages/auth/index.ts)
The expo plugin is configured with `baseURL` but the trustedOrigins may need wildcards for development mode.

---

## Recommended Fix

1. **Rewrite login.tsx** to use `authClient.signIn.social()` instead of manual fetch/WebBrowser calls

2. **Update trustedOrigins** to include development wildcards:
```typescript
trustedOrigins: [
    "taskmanager://",
    "exp://",
    "exp://**",
    "http://localhost:3000",
    "http://localhost:3001",
    "https://f2c05ede579e.ngrok-free.app",
]
```

3. **Ensure baseURL** in expo plugin matches the ngrok URL being used
